﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestCsSwig
{
    class Program
    {
        static void Main(string[] args)
        {
            Tir tir1 = new Tir();
            tir1.add(2, 4);
            tir1.affiche();
            vector_co v = new vector_co();
            v.Add(new Coordonnee(5, 8));
            v.Add(new Coordonnee(7, 10));
            tir1.add(v);
            tir1.affiche();
            Console.ReadKey();
        }
    }
}
