#pragma once
#include <vector>
#include <iostream>

#include "Coordonnee.h"
using namespace std;

class  Tir
{
private:
	vector<Coordonnee> tabDeCoord;
public:
	void add(int x,int y);
	void add(vector<Coordonnee>& tabc);
	void affiche();
};

