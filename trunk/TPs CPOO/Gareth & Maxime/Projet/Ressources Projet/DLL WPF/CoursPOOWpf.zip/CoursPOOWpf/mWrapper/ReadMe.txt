﻿========================================================================
    BIBLIOTHÈQUE DE LIENS DYNAMIQUES : Vue d'ensemble du projet 
    mWrapper
========================================================================

AppWizard a créé cette DLL mWrapper pour vous.  

Ce fichier contient un résumé des éléments contenus dans chaque fichier qui
constitue votre application mWrapper.

mWrapper.vcxproj
    Il s'agit du fichier projet principal pour les projets VC++ générés à 
    l'aide d'un Assistant Application. 
    Il contient des informations relatives à la version de Visual C++ qui a 
    généré le fichier, ainsi que des informations sur les plateformes, 
    configurations et fonctionnalités du projet que vous avez sélectionnées dans
    l'Assistant Application.

mWrapper.vcxproj.filters
    Il s'agit du fichier de filtres pour les projets VC++ générés à l'aide d'un 
    Assistant Application. 
    Il contient des informations sur l'association entre les fichiers de votre 
    projet et les filtres. Cette association est utilisée dans l'IDE pour 
    afficher le regroupement des fichiers qui ont des extensions similares sous 
    un nœud spécifique (par exemple, les fichiers ".cpp" sont associés au 
    filtre "Fichiers sources").

mWrapper.cpp
    Il s'agit du fichier source principal de la DLL.

mWrapper.h
    Ce fichier contient une déclaration de classe.

AssemblyInfo.cpp
    Contient des attributs personnalisés pour modifier les métadonnées de 
    l'assembly.

/////////////////////////////////////////////////////////////////////////////
Autres remarques :

AppWizard utilise des commentaires "TODO:" pour indiquer les parties du code 
source où vous devrez ajouter ou modifier du code.

/////////////////////////////////////////////////////////////////////////////
