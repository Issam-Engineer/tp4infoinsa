// Il s'agit du fichier DLL principal.

#include "stdafx.h"

#include "mWrapper.h"

