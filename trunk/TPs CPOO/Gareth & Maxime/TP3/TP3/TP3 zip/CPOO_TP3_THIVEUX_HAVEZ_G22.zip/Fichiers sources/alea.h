// alea.h

#ifndef ALEA_H
#define ALEA_H

class Alea { 
public:
  static int engendrer(int);
};

#endif
